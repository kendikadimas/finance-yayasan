<?php if($response): ?>
<?php echo $response->head; ?>

<?php else: ?>
<?php echo $slot; ?>

<?php endif; ?><?php /**PATH D:\laragon\www\finance-yayasan\storage\framework\views/9f98d2d3a8d06ea66f20db3a09929d70.blade.php ENDPATH**/ ?>