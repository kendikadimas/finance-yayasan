<?php echo e($slot); ?>

<?php /**PATH D:\laragon\www\finance-yayasan\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>