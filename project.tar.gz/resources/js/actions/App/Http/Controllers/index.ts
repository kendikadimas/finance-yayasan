import Api from './Api'
import DashboardController from './DashboardController'
import Settings from './Settings'
import Keuangan from './Keuangan'
const Controllers = {
    Api: Object.assign(Api, Api),
DashboardController: Object.assign(DashboardController, DashboardController),
Settings: Object.assign(Settings, Settings),
Keuangan: Object.assign(Keuangan, Keuangan),
}

export default Controllers