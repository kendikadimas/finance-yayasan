import UnitController from './UnitController'
import MetodePembayaranController from './MetodePembayaranController'
import EwsSettingController from './EwsSettingController'
import UserController from './UserController'
import ApiClientController from './ApiClientController'
import VendorController from './VendorController'
import AnggaranController from './AnggaranController'
import KasBankAccountController from './KasBankAccountController'
import TagihanSiswaController from './TagihanSiswaController'
import TransaksiController from './TransaksiController'
import PenggajianController from './PenggajianController'
import HutangVendorController from './HutangVendorController'
import LaporanController from './LaporanController'
import NotificationController from './NotificationController'
const Keuangan = {
    UnitController: Object.assign(UnitController, UnitController),
MetodePembayaranController: Object.assign(MetodePembayaranController, MetodePembayaranController),
EwsSettingController: Object.assign(EwsSettingController, EwsSettingController),
UserController: Object.assign(UserController, UserController),
ApiClientController: Object.assign(ApiClientController, ApiClientController),
VendorController: Object.assign(VendorController, VendorController),
AnggaranController: Object.assign(AnggaranController, AnggaranController),
KasBankAccountController: Object.assign(KasBankAccountController, KasBankAccountController),
TagihanSiswaController: Object.assign(TagihanSiswaController, TagihanSiswaController),
TransaksiController: Object.assign(TransaksiController, TransaksiController),
PenggajianController: Object.assign(PenggajianController, PenggajianController),
HutangVendorController: Object.assign(HutangVendorController, HutangVendorController),
LaporanController: Object.assign(LaporanController, LaporanController),
NotificationController: Object.assign(NotificationController, NotificationController),
}

export default Keuangan