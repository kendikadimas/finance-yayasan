import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Keuangan\LaporanController::perUnit
 * @see app/Http/Controllers/Keuangan/LaporanController.php:67
 * @route '/keuangan/laporan/unit/{unit}'
 */
export const perUnit = (args: { unit: number | { id: number } } | [unit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: perUnit.url(args, options),
    method: 'get',
})

perUnit.definition = {
    methods: ["get","head"],
    url: '/keuangan/laporan/unit/{unit}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Keuangan\LaporanController::perUnit
 * @see app/Http/Controllers/Keuangan/LaporanController.php:67
 * @route '/keuangan/laporan/unit/{unit}'
 */
perUnit.url = (args: { unit: number | { id: number } } | [unit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unit: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { unit: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    unit: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        unit: typeof args.unit === 'object'
                ? args.unit.id
                : args.unit,
                }

    return perUnit.definition.url
            .replace('{unit}', parsedArgs.unit.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\LaporanController::perUnit
 * @see app/Http/Controllers/Keuangan/LaporanController.php:67
 * @route '/keuangan/laporan/unit/{unit}'
 */
perUnit.get = (args: { unit: number | { id: number } } | [unit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: perUnit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Keuangan\LaporanController::perUnit
 * @see app/Http/Controllers/Keuangan/LaporanController.php:67
 * @route '/keuangan/laporan/unit/{unit}'
 */
perUnit.head = (args: { unit: number | { id: number } } | [unit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: perUnit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Keuangan\LaporanController::perUnit
 * @see app/Http/Controllers/Keuangan/LaporanController.php:67
 * @route '/keuangan/laporan/unit/{unit}'
 */
    const perUnitForm = (args: { unit: number | { id: number } } | [unit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: perUnit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Keuangan\LaporanController::perUnit
 * @see app/Http/Controllers/Keuangan/LaporanController.php:67
 * @route '/keuangan/laporan/unit/{unit}'
 */
        perUnitForm.get = (args: { unit: number | { id: number } } | [unit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: perUnit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Keuangan\LaporanController::perUnit
 * @see app/Http/Controllers/Keuangan/LaporanController.php:67
 * @route '/keuangan/laporan/unit/{unit}'
 */
        perUnitForm.head = (args: { unit: number | { id: number } } | [unit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: perUnit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    perUnit.form = perUnitForm
/**
* @see \App\Http\Controllers\Keuangan\LaporanController::proyeksiSes
 * @see app/Http/Controllers/Keuangan/LaporanController.php:128
 * @route '/keuangan/laporan/unit/{unit}/proyeksi-ses'
 */
export const proyeksiSes = (args: { unit: number | { id: number } } | [unit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: proyeksiSes.url(args, options),
    method: 'get',
})

proyeksiSes.definition = {
    methods: ["get","head"],
    url: '/keuangan/laporan/unit/{unit}/proyeksi-ses',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Keuangan\LaporanController::proyeksiSes
 * @see app/Http/Controllers/Keuangan/LaporanController.php:128
 * @route '/keuangan/laporan/unit/{unit}/proyeksi-ses'
 */
proyeksiSes.url = (args: { unit: number | { id: number } } | [unit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unit: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { unit: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    unit: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        unit: typeof args.unit === 'object'
                ? args.unit.id
                : args.unit,
                }

    return proyeksiSes.definition.url
            .replace('{unit}', parsedArgs.unit.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\LaporanController::proyeksiSes
 * @see app/Http/Controllers/Keuangan/LaporanController.php:128
 * @route '/keuangan/laporan/unit/{unit}/proyeksi-ses'
 */
proyeksiSes.get = (args: { unit: number | { id: number } } | [unit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: proyeksiSes.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Keuangan\LaporanController::proyeksiSes
 * @see app/Http/Controllers/Keuangan/LaporanController.php:128
 * @route '/keuangan/laporan/unit/{unit}/proyeksi-ses'
 */
proyeksiSes.head = (args: { unit: number | { id: number } } | [unit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: proyeksiSes.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Keuangan\LaporanController::proyeksiSes
 * @see app/Http/Controllers/Keuangan/LaporanController.php:128
 * @route '/keuangan/laporan/unit/{unit}/proyeksi-ses'
 */
    const proyeksiSesForm = (args: { unit: number | { id: number } } | [unit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: proyeksiSes.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Keuangan\LaporanController::proyeksiSes
 * @see app/Http/Controllers/Keuangan/LaporanController.php:128
 * @route '/keuangan/laporan/unit/{unit}/proyeksi-ses'
 */
        proyeksiSesForm.get = (args: { unit: number | { id: number } } | [unit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: proyeksiSes.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Keuangan\LaporanController::proyeksiSes
 * @see app/Http/Controllers/Keuangan/LaporanController.php:128
 * @route '/keuangan/laporan/unit/{unit}/proyeksi-ses'
 */
        proyeksiSesForm.head = (args: { unit: number | { id: number } } | [unit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: proyeksiSes.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    proyeksiSes.form = proyeksiSesForm
/**
* @see \App\Http\Controllers\Keuangan\LaporanController::simpanProyeksiSes
 * @see app/Http/Controllers/Keuangan/LaporanController.php:157
 * @route '/keuangan/laporan/unit/{unit}/proyeksi-ses'
 */
export const simpanProyeksiSes = (args: { unit: number | { id: number } } | [unit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: simpanProyeksiSes.url(args, options),
    method: 'post',
})

simpanProyeksiSes.definition = {
    methods: ["post"],
    url: '/keuangan/laporan/unit/{unit}/proyeksi-ses',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Keuangan\LaporanController::simpanProyeksiSes
 * @see app/Http/Controllers/Keuangan/LaporanController.php:157
 * @route '/keuangan/laporan/unit/{unit}/proyeksi-ses'
 */
simpanProyeksiSes.url = (args: { unit: number | { id: number } } | [unit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unit: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { unit: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    unit: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        unit: typeof args.unit === 'object'
                ? args.unit.id
                : args.unit,
                }

    return simpanProyeksiSes.definition.url
            .replace('{unit}', parsedArgs.unit.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\LaporanController::simpanProyeksiSes
 * @see app/Http/Controllers/Keuangan/LaporanController.php:157
 * @route '/keuangan/laporan/unit/{unit}/proyeksi-ses'
 */
simpanProyeksiSes.post = (args: { unit: number | { id: number } } | [unit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: simpanProyeksiSes.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Keuangan\LaporanController::simpanProyeksiSes
 * @see app/Http/Controllers/Keuangan/LaporanController.php:157
 * @route '/keuangan/laporan/unit/{unit}/proyeksi-ses'
 */
    const simpanProyeksiSesForm = (args: { unit: number | { id: number } } | [unit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: simpanProyeksiSes.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\LaporanController::simpanProyeksiSes
 * @see app/Http/Controllers/Keuangan/LaporanController.php:157
 * @route '/keuangan/laporan/unit/{unit}/proyeksi-ses'
 */
        simpanProyeksiSesForm.post = (args: { unit: number | { id: number } } | [unit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: simpanProyeksiSes.url(args, options),
            method: 'post',
        })
    
    simpanProyeksiSes.form = simpanProyeksiSesForm
/**
* @see \App\Http\Controllers\Keuangan\LaporanController::konsolidasi
 * @see app/Http/Controllers/Keuangan/LaporanController.php:109
 * @route '/keuangan/laporan/konsolidasi'
 */
export const konsolidasi = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: konsolidasi.url(options),
    method: 'get',
})

konsolidasi.definition = {
    methods: ["get","head"],
    url: '/keuangan/laporan/konsolidasi',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Keuangan\LaporanController::konsolidasi
 * @see app/Http/Controllers/Keuangan/LaporanController.php:109
 * @route '/keuangan/laporan/konsolidasi'
 */
konsolidasi.url = (options?: RouteQueryOptions) => {
    return konsolidasi.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\LaporanController::konsolidasi
 * @see app/Http/Controllers/Keuangan/LaporanController.php:109
 * @route '/keuangan/laporan/konsolidasi'
 */
konsolidasi.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: konsolidasi.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Keuangan\LaporanController::konsolidasi
 * @see app/Http/Controllers/Keuangan/LaporanController.php:109
 * @route '/keuangan/laporan/konsolidasi'
 */
konsolidasi.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: konsolidasi.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Keuangan\LaporanController::konsolidasi
 * @see app/Http/Controllers/Keuangan/LaporanController.php:109
 * @route '/keuangan/laporan/konsolidasi'
 */
    const konsolidasiForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: konsolidasi.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Keuangan\LaporanController::konsolidasi
 * @see app/Http/Controllers/Keuangan/LaporanController.php:109
 * @route '/keuangan/laporan/konsolidasi'
 */
        konsolidasiForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: konsolidasi.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Keuangan\LaporanController::konsolidasi
 * @see app/Http/Controllers/Keuangan/LaporanController.php:109
 * @route '/keuangan/laporan/konsolidasi'
 */
        konsolidasiForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: konsolidasi.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    konsolidasi.form = konsolidasiForm
/**
* @see \App\Http\Controllers\Keuangan\LaporanController::dashboardEws
 * @see app/Http/Controllers/Keuangan/LaporanController.php:34
 * @route '/keuangan/laporan/dashboard-ews'
 */
export const dashboardEws = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboardEws.url(options),
    method: 'get',
})

dashboardEws.definition = {
    methods: ["get","head"],
    url: '/keuangan/laporan/dashboard-ews',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Keuangan\LaporanController::dashboardEws
 * @see app/Http/Controllers/Keuangan/LaporanController.php:34
 * @route '/keuangan/laporan/dashboard-ews'
 */
dashboardEws.url = (options?: RouteQueryOptions) => {
    return dashboardEws.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\LaporanController::dashboardEws
 * @see app/Http/Controllers/Keuangan/LaporanController.php:34
 * @route '/keuangan/laporan/dashboard-ews'
 */
dashboardEws.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboardEws.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Keuangan\LaporanController::dashboardEws
 * @see app/Http/Controllers/Keuangan/LaporanController.php:34
 * @route '/keuangan/laporan/dashboard-ews'
 */
dashboardEws.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboardEws.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Keuangan\LaporanController::dashboardEws
 * @see app/Http/Controllers/Keuangan/LaporanController.php:34
 * @route '/keuangan/laporan/dashboard-ews'
 */
    const dashboardEwsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: dashboardEws.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Keuangan\LaporanController::dashboardEws
 * @see app/Http/Controllers/Keuangan/LaporanController.php:34
 * @route '/keuangan/laporan/dashboard-ews'
 */
        dashboardEwsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboardEws.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Keuangan\LaporanController::dashboardEws
 * @see app/Http/Controllers/Keuangan/LaporanController.php:34
 * @route '/keuangan/laporan/dashboard-ews'
 */
        dashboardEwsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboardEws.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    dashboardEws.form = dashboardEwsForm
const LaporanController = { perUnit, proyeksiSes, simpanProyeksiSes, konsolidasi, dashboardEws }

export default LaporanController