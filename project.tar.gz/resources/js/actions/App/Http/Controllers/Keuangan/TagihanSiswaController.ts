import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Keuangan\TagihanSiswaController::index
 * @see app/Http/Controllers/Keuangan/TagihanSiswaController.php:22
 * @route '/keuangan/tagihan-siswa'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/keuangan/tagihan-siswa',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Keuangan\TagihanSiswaController::index
 * @see app/Http/Controllers/Keuangan/TagihanSiswaController.php:22
 * @route '/keuangan/tagihan-siswa'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\TagihanSiswaController::index
 * @see app/Http/Controllers/Keuangan/TagihanSiswaController.php:22
 * @route '/keuangan/tagihan-siswa'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Keuangan\TagihanSiswaController::index
 * @see app/Http/Controllers/Keuangan/TagihanSiswaController.php:22
 * @route '/keuangan/tagihan-siswa'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Keuangan\TagihanSiswaController::index
 * @see app/Http/Controllers/Keuangan/TagihanSiswaController.php:22
 * @route '/keuangan/tagihan-siswa'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Keuangan\TagihanSiswaController::index
 * @see app/Http/Controllers/Keuangan/TagihanSiswaController.php:22
 * @route '/keuangan/tagihan-siswa'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Keuangan\TagihanSiswaController::index
 * @see app/Http/Controllers/Keuangan/TagihanSiswaController.php:22
 * @route '/keuangan/tagihan-siswa'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Keuangan\TagihanSiswaController::store
 * @see app/Http/Controllers/Keuangan/TagihanSiswaController.php:39
 * @route '/keuangan/tagihan-siswa'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/keuangan/tagihan-siswa',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Keuangan\TagihanSiswaController::store
 * @see app/Http/Controllers/Keuangan/TagihanSiswaController.php:39
 * @route '/keuangan/tagihan-siswa'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\TagihanSiswaController::store
 * @see app/Http/Controllers/Keuangan/TagihanSiswaController.php:39
 * @route '/keuangan/tagihan-siswa'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Keuangan\TagihanSiswaController::store
 * @see app/Http/Controllers/Keuangan/TagihanSiswaController.php:39
 * @route '/keuangan/tagihan-siswa'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\TagihanSiswaController::store
 * @see app/Http/Controllers/Keuangan/TagihanSiswaController.php:39
 * @route '/keuangan/tagihan-siswa'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Keuangan\TagihanSiswaController::update
 * @see app/Http/Controllers/Keuangan/TagihanSiswaController.php:67
 * @route '/keuangan/tagihan-siswa/{tagihan_siswa}'
 */
export const update = (args: { tagihan_siswa: number | { id: number } } | [tagihan_siswa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/keuangan/tagihan-siswa/{tagihan_siswa}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Keuangan\TagihanSiswaController::update
 * @see app/Http/Controllers/Keuangan/TagihanSiswaController.php:67
 * @route '/keuangan/tagihan-siswa/{tagihan_siswa}'
 */
update.url = (args: { tagihan_siswa: number | { id: number } } | [tagihan_siswa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { tagihan_siswa: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { tagihan_siswa: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    tagihan_siswa: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        tagihan_siswa: typeof args.tagihan_siswa === 'object'
                ? args.tagihan_siswa.id
                : args.tagihan_siswa,
                }

    return update.definition.url
            .replace('{tagihan_siswa}', parsedArgs.tagihan_siswa.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\TagihanSiswaController::update
 * @see app/Http/Controllers/Keuangan/TagihanSiswaController.php:67
 * @route '/keuangan/tagihan-siswa/{tagihan_siswa}'
 */
update.put = (args: { tagihan_siswa: number | { id: number } } | [tagihan_siswa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Keuangan\TagihanSiswaController::update
 * @see app/Http/Controllers/Keuangan/TagihanSiswaController.php:67
 * @route '/keuangan/tagihan-siswa/{tagihan_siswa}'
 */
    const updateForm = (args: { tagihan_siswa: number | { id: number } } | [tagihan_siswa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\TagihanSiswaController::update
 * @see app/Http/Controllers/Keuangan/TagihanSiswaController.php:67
 * @route '/keuangan/tagihan-siswa/{tagihan_siswa}'
 */
        updateForm.put = (args: { tagihan_siswa: number | { id: number } } | [tagihan_siswa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Keuangan\TagihanSiswaController::bayar
 * @see app/Http/Controllers/Keuangan/TagihanSiswaController.php:96
 * @route '/keuangan/tagihan-siswa/{tagihan_siswa}/bayar'
 */
export const bayar = (args: { tagihan_siswa: number | { id: number } } | [tagihan_siswa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bayar.url(args, options),
    method: 'post',
})

bayar.definition = {
    methods: ["post"],
    url: '/keuangan/tagihan-siswa/{tagihan_siswa}/bayar',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Keuangan\TagihanSiswaController::bayar
 * @see app/Http/Controllers/Keuangan/TagihanSiswaController.php:96
 * @route '/keuangan/tagihan-siswa/{tagihan_siswa}/bayar'
 */
bayar.url = (args: { tagihan_siswa: number | { id: number } } | [tagihan_siswa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { tagihan_siswa: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { tagihan_siswa: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    tagihan_siswa: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        tagihan_siswa: typeof args.tagihan_siswa === 'object'
                ? args.tagihan_siswa.id
                : args.tagihan_siswa,
                }

    return bayar.definition.url
            .replace('{tagihan_siswa}', parsedArgs.tagihan_siswa.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\TagihanSiswaController::bayar
 * @see app/Http/Controllers/Keuangan/TagihanSiswaController.php:96
 * @route '/keuangan/tagihan-siswa/{tagihan_siswa}/bayar'
 */
bayar.post = (args: { tagihan_siswa: number | { id: number } } | [tagihan_siswa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bayar.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Keuangan\TagihanSiswaController::bayar
 * @see app/Http/Controllers/Keuangan/TagihanSiswaController.php:96
 * @route '/keuangan/tagihan-siswa/{tagihan_siswa}/bayar'
 */
    const bayarForm = (args: { tagihan_siswa: number | { id: number } } | [tagihan_siswa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: bayar.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\TagihanSiswaController::bayar
 * @see app/Http/Controllers/Keuangan/TagihanSiswaController.php:96
 * @route '/keuangan/tagihan-siswa/{tagihan_siswa}/bayar'
 */
        bayarForm.post = (args: { tagihan_siswa: number | { id: number } } | [tagihan_siswa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: bayar.url(args, options),
            method: 'post',
        })
    
    bayar.form = bayarForm
/**
* @see \App\Http\Controllers\Keuangan\TagihanSiswaController::destroy
 * @see app/Http/Controllers/Keuangan/TagihanSiswaController.php:124
 * @route '/keuangan/tagihan-siswa/{tagihan_siswa}'
 */
export const destroy = (args: { tagihan_siswa: number | { id: number } } | [tagihan_siswa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/keuangan/tagihan-siswa/{tagihan_siswa}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Keuangan\TagihanSiswaController::destroy
 * @see app/Http/Controllers/Keuangan/TagihanSiswaController.php:124
 * @route '/keuangan/tagihan-siswa/{tagihan_siswa}'
 */
destroy.url = (args: { tagihan_siswa: number | { id: number } } | [tagihan_siswa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { tagihan_siswa: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { tagihan_siswa: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    tagihan_siswa: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        tagihan_siswa: typeof args.tagihan_siswa === 'object'
                ? args.tagihan_siswa.id
                : args.tagihan_siswa,
                }

    return destroy.definition.url
            .replace('{tagihan_siswa}', parsedArgs.tagihan_siswa.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\TagihanSiswaController::destroy
 * @see app/Http/Controllers/Keuangan/TagihanSiswaController.php:124
 * @route '/keuangan/tagihan-siswa/{tagihan_siswa}'
 */
destroy.delete = (args: { tagihan_siswa: number | { id: number } } | [tagihan_siswa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Keuangan\TagihanSiswaController::destroy
 * @see app/Http/Controllers/Keuangan/TagihanSiswaController.php:124
 * @route '/keuangan/tagihan-siswa/{tagihan_siswa}'
 */
    const destroyForm = (args: { tagihan_siswa: number | { id: number } } | [tagihan_siswa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\TagihanSiswaController::destroy
 * @see app/Http/Controllers/Keuangan/TagihanSiswaController.php:124
 * @route '/keuangan/tagihan-siswa/{tagihan_siswa}'
 */
        destroyForm.delete = (args: { tagihan_siswa: number | { id: number } } | [tagihan_siswa: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const TagihanSiswaController = { index, store, update, bayar, destroy }

export default TagihanSiswaController