import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Keuangan\MetodePembayaranController::store
 * @see app/Http/Controllers/Keuangan/MetodePembayaranController.php:24
 * @route '/keuangan/metode-pembayaran'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/keuangan/metode-pembayaran',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Keuangan\MetodePembayaranController::store
 * @see app/Http/Controllers/Keuangan/MetodePembayaranController.php:24
 * @route '/keuangan/metode-pembayaran'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\MetodePembayaranController::store
 * @see app/Http/Controllers/Keuangan/MetodePembayaranController.php:24
 * @route '/keuangan/metode-pembayaran'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Keuangan\MetodePembayaranController::store
 * @see app/Http/Controllers/Keuangan/MetodePembayaranController.php:24
 * @route '/keuangan/metode-pembayaran'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\MetodePembayaranController::store
 * @see app/Http/Controllers/Keuangan/MetodePembayaranController.php:24
 * @route '/keuangan/metode-pembayaran'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Keuangan\MetodePembayaranController::update
 * @see app/Http/Controllers/Keuangan/MetodePembayaranController.php:38
 * @route '/keuangan/metode-pembayaran/{metode_pembayaran}'
 */
export const update = (args: { metode_pembayaran: number | { id: number } } | [metode_pembayaran: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/keuangan/metode-pembayaran/{metode_pembayaran}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Keuangan\MetodePembayaranController::update
 * @see app/Http/Controllers/Keuangan/MetodePembayaranController.php:38
 * @route '/keuangan/metode-pembayaran/{metode_pembayaran}'
 */
update.url = (args: { metode_pembayaran: number | { id: number } } | [metode_pembayaran: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { metode_pembayaran: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { metode_pembayaran: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    metode_pembayaran: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        metode_pembayaran: typeof args.metode_pembayaran === 'object'
                ? args.metode_pembayaran.id
                : args.metode_pembayaran,
                }

    return update.definition.url
            .replace('{metode_pembayaran}', parsedArgs.metode_pembayaran.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\MetodePembayaranController::update
 * @see app/Http/Controllers/Keuangan/MetodePembayaranController.php:38
 * @route '/keuangan/metode-pembayaran/{metode_pembayaran}'
 */
update.put = (args: { metode_pembayaran: number | { id: number } } | [metode_pembayaran: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Keuangan\MetodePembayaranController::update
 * @see app/Http/Controllers/Keuangan/MetodePembayaranController.php:38
 * @route '/keuangan/metode-pembayaran/{metode_pembayaran}'
 */
    const updateForm = (args: { metode_pembayaran: number | { id: number } } | [metode_pembayaran: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\MetodePembayaranController::update
 * @see app/Http/Controllers/Keuangan/MetodePembayaranController.php:38
 * @route '/keuangan/metode-pembayaran/{metode_pembayaran}'
 */
        updateForm.put = (args: { metode_pembayaran: number | { id: number } } | [metode_pembayaran: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Keuangan\MetodePembayaranController::destroy
 * @see app/Http/Controllers/Keuangan/MetodePembayaranController.php:52
 * @route '/keuangan/metode-pembayaran/{metode_pembayaran}'
 */
export const destroy = (args: { metode_pembayaran: number | { id: number } } | [metode_pembayaran: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/keuangan/metode-pembayaran/{metode_pembayaran}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Keuangan\MetodePembayaranController::destroy
 * @see app/Http/Controllers/Keuangan/MetodePembayaranController.php:52
 * @route '/keuangan/metode-pembayaran/{metode_pembayaran}'
 */
destroy.url = (args: { metode_pembayaran: number | { id: number } } | [metode_pembayaran: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { metode_pembayaran: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { metode_pembayaran: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    metode_pembayaran: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        metode_pembayaran: typeof args.metode_pembayaran === 'object'
                ? args.metode_pembayaran.id
                : args.metode_pembayaran,
                }

    return destroy.definition.url
            .replace('{metode_pembayaran}', parsedArgs.metode_pembayaran.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\MetodePembayaranController::destroy
 * @see app/Http/Controllers/Keuangan/MetodePembayaranController.php:52
 * @route '/keuangan/metode-pembayaran/{metode_pembayaran}'
 */
destroy.delete = (args: { metode_pembayaran: number | { id: number } } | [metode_pembayaran: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Keuangan\MetodePembayaranController::destroy
 * @see app/Http/Controllers/Keuangan/MetodePembayaranController.php:52
 * @route '/keuangan/metode-pembayaran/{metode_pembayaran}'
 */
    const destroyForm = (args: { metode_pembayaran: number | { id: number } } | [metode_pembayaran: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\MetodePembayaranController::destroy
 * @see app/Http/Controllers/Keuangan/MetodePembayaranController.php:52
 * @route '/keuangan/metode-pembayaran/{metode_pembayaran}'
 */
        destroyForm.delete = (args: { metode_pembayaran: number | { id: number } } | [metode_pembayaran: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Keuangan\MetodePembayaranController::index
 * @see app/Http/Controllers/Keuangan/MetodePembayaranController.php:17
 * @route '/keuangan/metode-pembayaran'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/keuangan/metode-pembayaran',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Keuangan\MetodePembayaranController::index
 * @see app/Http/Controllers/Keuangan/MetodePembayaranController.php:17
 * @route '/keuangan/metode-pembayaran'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\MetodePembayaranController::index
 * @see app/Http/Controllers/Keuangan/MetodePembayaranController.php:17
 * @route '/keuangan/metode-pembayaran'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Keuangan\MetodePembayaranController::index
 * @see app/Http/Controllers/Keuangan/MetodePembayaranController.php:17
 * @route '/keuangan/metode-pembayaran'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Keuangan\MetodePembayaranController::index
 * @see app/Http/Controllers/Keuangan/MetodePembayaranController.php:17
 * @route '/keuangan/metode-pembayaran'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Keuangan\MetodePembayaranController::index
 * @see app/Http/Controllers/Keuangan/MetodePembayaranController.php:17
 * @route '/keuangan/metode-pembayaran'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Keuangan\MetodePembayaranController::index
 * @see app/Http/Controllers/Keuangan/MetodePembayaranController.php:17
 * @route '/keuangan/metode-pembayaran'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const MetodePembayaranController = { store, update, destroy, index }

export default MetodePembayaranController