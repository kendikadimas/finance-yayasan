import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Keuangan\EwsSettingController::edit
 * @see app/Http/Controllers/Keuangan/EwsSettingController.php:17
 * @route '/keuangan/ews-setting'
 */
export const edit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/keuangan/ews-setting',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Keuangan\EwsSettingController::edit
 * @see app/Http/Controllers/Keuangan/EwsSettingController.php:17
 * @route '/keuangan/ews-setting'
 */
edit.url = (options?: RouteQueryOptions) => {
    return edit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\EwsSettingController::edit
 * @see app/Http/Controllers/Keuangan/EwsSettingController.php:17
 * @route '/keuangan/ews-setting'
 */
edit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Keuangan\EwsSettingController::edit
 * @see app/Http/Controllers/Keuangan/EwsSettingController.php:17
 * @route '/keuangan/ews-setting'
 */
edit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Keuangan\EwsSettingController::edit
 * @see app/Http/Controllers/Keuangan/EwsSettingController.php:17
 * @route '/keuangan/ews-setting'
 */
    const editForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Keuangan\EwsSettingController::edit
 * @see app/Http/Controllers/Keuangan/EwsSettingController.php:17
 * @route '/keuangan/ews-setting'
 */
        editForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Keuangan\EwsSettingController::edit
 * @see app/Http/Controllers/Keuangan/EwsSettingController.php:17
 * @route '/keuangan/ews-setting'
 */
        editForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Keuangan\EwsSettingController::update
 * @see app/Http/Controllers/Keuangan/EwsSettingController.php:24
 * @route '/keuangan/ews-setting'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/keuangan/ews-setting',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Keuangan\EwsSettingController::update
 * @see app/Http/Controllers/Keuangan/EwsSettingController.php:24
 * @route '/keuangan/ews-setting'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\EwsSettingController::update
 * @see app/Http/Controllers/Keuangan/EwsSettingController.php:24
 * @route '/keuangan/ews-setting'
 */
update.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Keuangan\EwsSettingController::update
 * @see app/Http/Controllers/Keuangan/EwsSettingController.php:24
 * @route '/keuangan/ews-setting'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\EwsSettingController::update
 * @see app/Http/Controllers/Keuangan/EwsSettingController.php:24
 * @route '/keuangan/ews-setting'
 */
        updateForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const EwsSettingController = { edit, update }

export default EwsSettingController