import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\V1\LaporanRingkasanController::index
 * @see app/Http/Controllers/Api/V1/LaporanRingkasanController.php:21
 * @route '/api/v1/laporan/ringkasan'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/v1/laporan/ringkasan',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\LaporanRingkasanController::index
 * @see app/Http/Controllers/Api/V1/LaporanRingkasanController.php:21
 * @route '/api/v1/laporan/ringkasan'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\LaporanRingkasanController::index
 * @see app/Http/Controllers/Api/V1/LaporanRingkasanController.php:21
 * @route '/api/v1/laporan/ringkasan'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\V1\LaporanRingkasanController::index
 * @see app/Http/Controllers/Api/V1/LaporanRingkasanController.php:21
 * @route '/api/v1/laporan/ringkasan'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\V1\LaporanRingkasanController::index
 * @see app/Http/Controllers/Api/V1/LaporanRingkasanController.php:21
 * @route '/api/v1/laporan/ringkasan'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\V1\LaporanRingkasanController::index
 * @see app/Http/Controllers/Api/V1/LaporanRingkasanController.php:21
 * @route '/api/v1/laporan/ringkasan'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\V1\LaporanRingkasanController::index
 * @see app/Http/Controllers/Api/V1/LaporanRingkasanController.php:21
 * @route '/api/v1/laporan/ringkasan'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const LaporanRingkasanController = { index }

export default LaporanRingkasanController