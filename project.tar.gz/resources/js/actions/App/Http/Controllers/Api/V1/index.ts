import PembayaranSppController from './PembayaranSppController'
import TagihanSiswaController from './TagihanSiswaController'
import HutangVendorController from './HutangVendorController'
import PenggajianController from './PenggajianController'
import LaporanRingkasanController from './LaporanRingkasanController'
const V1 = {
    PembayaranSppController: Object.assign(PembayaranSppController, PembayaranSppController),
TagihanSiswaController: Object.assign(TagihanSiswaController, TagihanSiswaController),
HutangVendorController: Object.assign(HutangVendorController, HutangVendorController),
PenggajianController: Object.assign(PenggajianController, PenggajianController),
LaporanRingkasanController: Object.assign(LaporanRingkasanController, LaporanRingkasanController),
}

export default V1