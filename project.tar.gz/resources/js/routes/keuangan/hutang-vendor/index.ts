import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Keuangan\HutangVendorController::index
 * @see app/Http/Controllers/Keuangan/HutangVendorController.php:22
 * @route '/keuangan/hutang-vendor'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/keuangan/hutang-vendor',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Keuangan\HutangVendorController::index
 * @see app/Http/Controllers/Keuangan/HutangVendorController.php:22
 * @route '/keuangan/hutang-vendor'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\HutangVendorController::index
 * @see app/Http/Controllers/Keuangan/HutangVendorController.php:22
 * @route '/keuangan/hutang-vendor'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Keuangan\HutangVendorController::index
 * @see app/Http/Controllers/Keuangan/HutangVendorController.php:22
 * @route '/keuangan/hutang-vendor'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Keuangan\HutangVendorController::index
 * @see app/Http/Controllers/Keuangan/HutangVendorController.php:22
 * @route '/keuangan/hutang-vendor'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Keuangan\HutangVendorController::index
 * @see app/Http/Controllers/Keuangan/HutangVendorController.php:22
 * @route '/keuangan/hutang-vendor'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Keuangan\HutangVendorController::index
 * @see app/Http/Controllers/Keuangan/HutangVendorController.php:22
 * @route '/keuangan/hutang-vendor'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Keuangan\HutangVendorController::store
 * @see app/Http/Controllers/Keuangan/HutangVendorController.php:39
 * @route '/keuangan/hutang-vendor'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/keuangan/hutang-vendor',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Keuangan\HutangVendorController::store
 * @see app/Http/Controllers/Keuangan/HutangVendorController.php:39
 * @route '/keuangan/hutang-vendor'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\HutangVendorController::store
 * @see app/Http/Controllers/Keuangan/HutangVendorController.php:39
 * @route '/keuangan/hutang-vendor'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Keuangan\HutangVendorController::store
 * @see app/Http/Controllers/Keuangan/HutangVendorController.php:39
 * @route '/keuangan/hutang-vendor'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\HutangVendorController::store
 * @see app/Http/Controllers/Keuangan/HutangVendorController.php:39
 * @route '/keuangan/hutang-vendor'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Keuangan\HutangVendorController::update
 * @see app/Http/Controllers/Keuangan/HutangVendorController.php:61
 * @route '/keuangan/hutang-vendor/{hutang_vendor}'
 */
export const update = (args: { hutang_vendor: number | { id: number } } | [hutang_vendor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/keuangan/hutang-vendor/{hutang_vendor}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Keuangan\HutangVendorController::update
 * @see app/Http/Controllers/Keuangan/HutangVendorController.php:61
 * @route '/keuangan/hutang-vendor/{hutang_vendor}'
 */
update.url = (args: { hutang_vendor: number | { id: number } } | [hutang_vendor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { hutang_vendor: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { hutang_vendor: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    hutang_vendor: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        hutang_vendor: typeof args.hutang_vendor === 'object'
                ? args.hutang_vendor.id
                : args.hutang_vendor,
                }

    return update.definition.url
            .replace('{hutang_vendor}', parsedArgs.hutang_vendor.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\HutangVendorController::update
 * @see app/Http/Controllers/Keuangan/HutangVendorController.php:61
 * @route '/keuangan/hutang-vendor/{hutang_vendor}'
 */
update.put = (args: { hutang_vendor: number | { id: number } } | [hutang_vendor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Keuangan\HutangVendorController::update
 * @see app/Http/Controllers/Keuangan/HutangVendorController.php:61
 * @route '/keuangan/hutang-vendor/{hutang_vendor}'
 */
    const updateForm = (args: { hutang_vendor: number | { id: number } } | [hutang_vendor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\HutangVendorController::update
 * @see app/Http/Controllers/Keuangan/HutangVendorController.php:61
 * @route '/keuangan/hutang-vendor/{hutang_vendor}'
 */
        updateForm.put = (args: { hutang_vendor: number | { id: number } } | [hutang_vendor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Keuangan\HutangVendorController::lunas
 * @see app/Http/Controllers/Keuangan/HutangVendorController.php:80
 * @route '/keuangan/hutang-vendor/{hutang_vendor}/lunas'
 */
export const lunas = (args: { hutang_vendor: number | { id: number } } | [hutang_vendor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: lunas.url(args, options),
    method: 'post',
})

lunas.definition = {
    methods: ["post"],
    url: '/keuangan/hutang-vendor/{hutang_vendor}/lunas',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Keuangan\HutangVendorController::lunas
 * @see app/Http/Controllers/Keuangan/HutangVendorController.php:80
 * @route '/keuangan/hutang-vendor/{hutang_vendor}/lunas'
 */
lunas.url = (args: { hutang_vendor: number | { id: number } } | [hutang_vendor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { hutang_vendor: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { hutang_vendor: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    hutang_vendor: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        hutang_vendor: typeof args.hutang_vendor === 'object'
                ? args.hutang_vendor.id
                : args.hutang_vendor,
                }

    return lunas.definition.url
            .replace('{hutang_vendor}', parsedArgs.hutang_vendor.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\HutangVendorController::lunas
 * @see app/Http/Controllers/Keuangan/HutangVendorController.php:80
 * @route '/keuangan/hutang-vendor/{hutang_vendor}/lunas'
 */
lunas.post = (args: { hutang_vendor: number | { id: number } } | [hutang_vendor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: lunas.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Keuangan\HutangVendorController::lunas
 * @see app/Http/Controllers/Keuangan/HutangVendorController.php:80
 * @route '/keuangan/hutang-vendor/{hutang_vendor}/lunas'
 */
    const lunasForm = (args: { hutang_vendor: number | { id: number } } | [hutang_vendor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: lunas.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\HutangVendorController::lunas
 * @see app/Http/Controllers/Keuangan/HutangVendorController.php:80
 * @route '/keuangan/hutang-vendor/{hutang_vendor}/lunas'
 */
        lunasForm.post = (args: { hutang_vendor: number | { id: number } } | [hutang_vendor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: lunas.url(args, options),
            method: 'post',
        })
    
    lunas.form = lunasForm
/**
* @see \App\Http\Controllers\Keuangan\HutangVendorController::destroy
 * @see app/Http/Controllers/Keuangan/HutangVendorController.php:111
 * @route '/keuangan/hutang-vendor/{hutang_vendor}'
 */
export const destroy = (args: { hutang_vendor: number | { id: number } } | [hutang_vendor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/keuangan/hutang-vendor/{hutang_vendor}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Keuangan\HutangVendorController::destroy
 * @see app/Http/Controllers/Keuangan/HutangVendorController.php:111
 * @route '/keuangan/hutang-vendor/{hutang_vendor}'
 */
destroy.url = (args: { hutang_vendor: number | { id: number } } | [hutang_vendor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { hutang_vendor: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { hutang_vendor: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    hutang_vendor: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        hutang_vendor: typeof args.hutang_vendor === 'object'
                ? args.hutang_vendor.id
                : args.hutang_vendor,
                }

    return destroy.definition.url
            .replace('{hutang_vendor}', parsedArgs.hutang_vendor.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\HutangVendorController::destroy
 * @see app/Http/Controllers/Keuangan/HutangVendorController.php:111
 * @route '/keuangan/hutang-vendor/{hutang_vendor}'
 */
destroy.delete = (args: { hutang_vendor: number | { id: number } } | [hutang_vendor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Keuangan\HutangVendorController::destroy
 * @see app/Http/Controllers/Keuangan/HutangVendorController.php:111
 * @route '/keuangan/hutang-vendor/{hutang_vendor}'
 */
    const destroyForm = (args: { hutang_vendor: number | { id: number } } | [hutang_vendor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\HutangVendorController::destroy
 * @see app/Http/Controllers/Keuangan/HutangVendorController.php:111
 * @route '/keuangan/hutang-vendor/{hutang_vendor}'
 */
        destroyForm.delete = (args: { hutang_vendor: number | { id: number } } | [hutang_vendor: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const hutangVendor = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
update: Object.assign(update, update),
lunas: Object.assign(lunas, lunas),
destroy: Object.assign(destroy, destroy),
}

export default hutangVendor