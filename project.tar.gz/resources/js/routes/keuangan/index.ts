import units from './units'
import metodePembayaran from './metode-pembayaran'
import ewsSetting from './ews-setting'
import users from './users'
import apiClients from './api-clients'
import vendors from './vendors'
import anggaran from './anggaran'
import kasBank from './kas-bank'
import tagihanSiswa from './tagihan-siswa'
import transaksi from './transaksi'
import penggajian from './penggajian'
import hutangVendor from './hutang-vendor'
import laporan from './laporan'
import notifications from './notifications'
const keuangan = {
    units: Object.assign(units, units),
metodePembayaran: Object.assign(metodePembayaran, metodePembayaran),
ewsSetting: Object.assign(ewsSetting, ewsSetting),
users: Object.assign(users, users),
apiClients: Object.assign(apiClients, apiClients),
vendors: Object.assign(vendors, vendors),
anggaran: Object.assign(anggaran, anggaran),
kasBank: Object.assign(kasBank, kasBank),
tagihanSiswa: Object.assign(tagihanSiswa, tagihanSiswa),
transaksi: Object.assign(transaksi, transaksi),
penggajian: Object.assign(penggajian, penggajian),
hutangVendor: Object.assign(hutangVendor, hutangVendor),
laporan: Object.assign(laporan, laporan),
notifications: Object.assign(notifications, notifications),
}

export default keuangan