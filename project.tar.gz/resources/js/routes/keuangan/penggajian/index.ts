import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Keuangan\PenggajianController::index
 * @see app/Http/Controllers/Keuangan/PenggajianController.php:21
 * @route '/keuangan/penggajian'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/keuangan/penggajian',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Keuangan\PenggajianController::index
 * @see app/Http/Controllers/Keuangan/PenggajianController.php:21
 * @route '/keuangan/penggajian'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\PenggajianController::index
 * @see app/Http/Controllers/Keuangan/PenggajianController.php:21
 * @route '/keuangan/penggajian'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Keuangan\PenggajianController::index
 * @see app/Http/Controllers/Keuangan/PenggajianController.php:21
 * @route '/keuangan/penggajian'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Keuangan\PenggajianController::index
 * @see app/Http/Controllers/Keuangan/PenggajianController.php:21
 * @route '/keuangan/penggajian'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Keuangan\PenggajianController::index
 * @see app/Http/Controllers/Keuangan/PenggajianController.php:21
 * @route '/keuangan/penggajian'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Keuangan\PenggajianController::index
 * @see app/Http/Controllers/Keuangan/PenggajianController.php:21
 * @route '/keuangan/penggajian'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Keuangan\PenggajianController::store
 * @see app/Http/Controllers/Keuangan/PenggajianController.php:37
 * @route '/keuangan/penggajian'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/keuangan/penggajian',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Keuangan\PenggajianController::store
 * @see app/Http/Controllers/Keuangan/PenggajianController.php:37
 * @route '/keuangan/penggajian'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\PenggajianController::store
 * @see app/Http/Controllers/Keuangan/PenggajianController.php:37
 * @route '/keuangan/penggajian'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Keuangan\PenggajianController::store
 * @see app/Http/Controllers/Keuangan/PenggajianController.php:37
 * @route '/keuangan/penggajian'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\PenggajianController::store
 * @see app/Http/Controllers/Keuangan/PenggajianController.php:37
 * @route '/keuangan/penggajian'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Keuangan\PenggajianController::update
 * @see app/Http/Controllers/Keuangan/PenggajianController.php:64
 * @route '/keuangan/penggajian/{penggajian}'
 */
export const update = (args: { penggajian: number | { id: number } } | [penggajian: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/keuangan/penggajian/{penggajian}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Keuangan\PenggajianController::update
 * @see app/Http/Controllers/Keuangan/PenggajianController.php:64
 * @route '/keuangan/penggajian/{penggajian}'
 */
update.url = (args: { penggajian: number | { id: number } } | [penggajian: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { penggajian: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { penggajian: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    penggajian: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        penggajian: typeof args.penggajian === 'object'
                ? args.penggajian.id
                : args.penggajian,
                }

    return update.definition.url
            .replace('{penggajian}', parsedArgs.penggajian.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\PenggajianController::update
 * @see app/Http/Controllers/Keuangan/PenggajianController.php:64
 * @route '/keuangan/penggajian/{penggajian}'
 */
update.put = (args: { penggajian: number | { id: number } } | [penggajian: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Keuangan\PenggajianController::update
 * @see app/Http/Controllers/Keuangan/PenggajianController.php:64
 * @route '/keuangan/penggajian/{penggajian}'
 */
    const updateForm = (args: { penggajian: number | { id: number } } | [penggajian: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\PenggajianController::update
 * @see app/Http/Controllers/Keuangan/PenggajianController.php:64
 * @route '/keuangan/penggajian/{penggajian}'
 */
        updateForm.put = (args: { penggajian: number | { id: number } } | [penggajian: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Keuangan\PenggajianController::bayar
 * @see app/Http/Controllers/Keuangan/PenggajianController.php:90
 * @route '/keuangan/penggajian/{penggajian}/bayar'
 */
export const bayar = (args: { penggajian: number | { id: number } } | [penggajian: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bayar.url(args, options),
    method: 'post',
})

bayar.definition = {
    methods: ["post"],
    url: '/keuangan/penggajian/{penggajian}/bayar',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Keuangan\PenggajianController::bayar
 * @see app/Http/Controllers/Keuangan/PenggajianController.php:90
 * @route '/keuangan/penggajian/{penggajian}/bayar'
 */
bayar.url = (args: { penggajian: number | { id: number } } | [penggajian: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { penggajian: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { penggajian: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    penggajian: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        penggajian: typeof args.penggajian === 'object'
                ? args.penggajian.id
                : args.penggajian,
                }

    return bayar.definition.url
            .replace('{penggajian}', parsedArgs.penggajian.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\PenggajianController::bayar
 * @see app/Http/Controllers/Keuangan/PenggajianController.php:90
 * @route '/keuangan/penggajian/{penggajian}/bayar'
 */
bayar.post = (args: { penggajian: number | { id: number } } | [penggajian: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bayar.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Keuangan\PenggajianController::bayar
 * @see app/Http/Controllers/Keuangan/PenggajianController.php:90
 * @route '/keuangan/penggajian/{penggajian}/bayar'
 */
    const bayarForm = (args: { penggajian: number | { id: number } } | [penggajian: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: bayar.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\PenggajianController::bayar
 * @see app/Http/Controllers/Keuangan/PenggajianController.php:90
 * @route '/keuangan/penggajian/{penggajian}/bayar'
 */
        bayarForm.post = (args: { penggajian: number | { id: number } } | [penggajian: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: bayar.url(args, options),
            method: 'post',
        })
    
    bayar.form = bayarForm
/**
* @see \App\Http\Controllers\Keuangan\PenggajianController::destroy
 * @see app/Http/Controllers/Keuangan/PenggajianController.php:120
 * @route '/keuangan/penggajian/{penggajian}'
 */
export const destroy = (args: { penggajian: number | { id: number } } | [penggajian: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/keuangan/penggajian/{penggajian}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Keuangan\PenggajianController::destroy
 * @see app/Http/Controllers/Keuangan/PenggajianController.php:120
 * @route '/keuangan/penggajian/{penggajian}'
 */
destroy.url = (args: { penggajian: number | { id: number } } | [penggajian: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { penggajian: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { penggajian: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    penggajian: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        penggajian: typeof args.penggajian === 'object'
                ? args.penggajian.id
                : args.penggajian,
                }

    return destroy.definition.url
            .replace('{penggajian}', parsedArgs.penggajian.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\PenggajianController::destroy
 * @see app/Http/Controllers/Keuangan/PenggajianController.php:120
 * @route '/keuangan/penggajian/{penggajian}'
 */
destroy.delete = (args: { penggajian: number | { id: number } } | [penggajian: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Keuangan\PenggajianController::destroy
 * @see app/Http/Controllers/Keuangan/PenggajianController.php:120
 * @route '/keuangan/penggajian/{penggajian}'
 */
    const destroyForm = (args: { penggajian: number | { id: number } } | [penggajian: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\PenggajianController::destroy
 * @see app/Http/Controllers/Keuangan/PenggajianController.php:120
 * @route '/keuangan/penggajian/{penggajian}'
 */
        destroyForm.delete = (args: { penggajian: number | { id: number } } | [penggajian: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const penggajian = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
update: Object.assign(update, update),
bayar: Object.assign(bayar, bayar),
destroy: Object.assign(destroy, destroy),
}

export default penggajian