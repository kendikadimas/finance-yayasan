import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Keuangan\LaporanController::store
 * @see app/Http/Controllers/Keuangan/LaporanController.php:157
 * @route '/keuangan/laporan/unit/{unit}/proyeksi-ses'
 */
export const store = (args: { unit: number | { id: number } } | [unit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/keuangan/laporan/unit/{unit}/proyeksi-ses',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Keuangan\LaporanController::store
 * @see app/Http/Controllers/Keuangan/LaporanController.php:157
 * @route '/keuangan/laporan/unit/{unit}/proyeksi-ses'
 */
store.url = (args: { unit: number | { id: number } } | [unit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unit: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { unit: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    unit: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        unit: typeof args.unit === 'object'
                ? args.unit.id
                : args.unit,
                }

    return store.definition.url
            .replace('{unit}', parsedArgs.unit.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\LaporanController::store
 * @see app/Http/Controllers/Keuangan/LaporanController.php:157
 * @route '/keuangan/laporan/unit/{unit}/proyeksi-ses'
 */
store.post = (args: { unit: number | { id: number } } | [unit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Keuangan\LaporanController::store
 * @see app/Http/Controllers/Keuangan/LaporanController.php:157
 * @route '/keuangan/laporan/unit/{unit}/proyeksi-ses'
 */
    const storeForm = (args: { unit: number | { id: number } } | [unit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\LaporanController::store
 * @see app/Http/Controllers/Keuangan/LaporanController.php:157
 * @route '/keuangan/laporan/unit/{unit}/proyeksi-ses'
 */
        storeForm.post = (args: { unit: number | { id: number } } | [unit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
const proyeksiSes = {
    store: Object.assign(store, store),
}

export default proyeksiSes