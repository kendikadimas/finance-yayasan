import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Keuangan\AnggaranController::index
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:21
 * @route '/keuangan/anggaran'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/keuangan/anggaran',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Keuangan\AnggaranController::index
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:21
 * @route '/keuangan/anggaran'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\AnggaranController::index
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:21
 * @route '/keuangan/anggaran'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Keuangan\AnggaranController::index
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:21
 * @route '/keuangan/anggaran'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Keuangan\AnggaranController::index
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:21
 * @route '/keuangan/anggaran'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Keuangan\AnggaranController::index
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:21
 * @route '/keuangan/anggaran'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Keuangan\AnggaranController::index
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:21
 * @route '/keuangan/anggaran'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Keuangan\AnggaranController::store
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:44
 * @route '/keuangan/anggaran'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/keuangan/anggaran',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Keuangan\AnggaranController::store
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:44
 * @route '/keuangan/anggaran'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\AnggaranController::store
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:44
 * @route '/keuangan/anggaran'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Keuangan\AnggaranController::store
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:44
 * @route '/keuangan/anggaran'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\AnggaranController::store
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:44
 * @route '/keuangan/anggaran'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Keuangan\AnggaranController::update
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:66
 * @route '/keuangan/anggaran/{anggaran}'
 */
export const update = (args: { anggaran: number | { id: number } } | [anggaran: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/keuangan/anggaran/{anggaran}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Keuangan\AnggaranController::update
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:66
 * @route '/keuangan/anggaran/{anggaran}'
 */
update.url = (args: { anggaran: number | { id: number } } | [anggaran: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { anggaran: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { anggaran: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    anggaran: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        anggaran: typeof args.anggaran === 'object'
                ? args.anggaran.id
                : args.anggaran,
                }

    return update.definition.url
            .replace('{anggaran}', parsedArgs.anggaran.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\AnggaranController::update
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:66
 * @route '/keuangan/anggaran/{anggaran}'
 */
update.put = (args: { anggaran: number | { id: number } } | [anggaran: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Keuangan\AnggaranController::update
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:66
 * @route '/keuangan/anggaran/{anggaran}'
 */
    const updateForm = (args: { anggaran: number | { id: number } } | [anggaran: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\AnggaranController::update
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:66
 * @route '/keuangan/anggaran/{anggaran}'
 */
        updateForm.put = (args: { anggaran: number | { id: number } } | [anggaran: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Keuangan\AnggaranController::ajukan
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:87
 * @route '/keuangan/anggaran/{anggaran}/ajukan'
 */
export const ajukan = (args: { anggaran: number | { id: number } } | [anggaran: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: ajukan.url(args, options),
    method: 'post',
})

ajukan.definition = {
    methods: ["post"],
    url: '/keuangan/anggaran/{anggaran}/ajukan',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Keuangan\AnggaranController::ajukan
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:87
 * @route '/keuangan/anggaran/{anggaran}/ajukan'
 */
ajukan.url = (args: { anggaran: number | { id: number } } | [anggaran: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { anggaran: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { anggaran: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    anggaran: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        anggaran: typeof args.anggaran === 'object'
                ? args.anggaran.id
                : args.anggaran,
                }

    return ajukan.definition.url
            .replace('{anggaran}', parsedArgs.anggaran.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\AnggaranController::ajukan
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:87
 * @route '/keuangan/anggaran/{anggaran}/ajukan'
 */
ajukan.post = (args: { anggaran: number | { id: number } } | [anggaran: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: ajukan.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Keuangan\AnggaranController::ajukan
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:87
 * @route '/keuangan/anggaran/{anggaran}/ajukan'
 */
    const ajukanForm = (args: { anggaran: number | { id: number } } | [anggaran: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: ajukan.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\AnggaranController::ajukan
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:87
 * @route '/keuangan/anggaran/{anggaran}/ajukan'
 */
        ajukanForm.post = (args: { anggaran: number | { id: number } } | [anggaran: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: ajukan.url(args, options),
            method: 'post',
        })
    
    ajukan.form = ajukanForm
/**
* @see \App\Http\Controllers\Keuangan\AnggaranController::destroy
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:128
 * @route '/keuangan/anggaran/{anggaran}'
 */
export const destroy = (args: { anggaran: number | { id: number } } | [anggaran: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/keuangan/anggaran/{anggaran}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Keuangan\AnggaranController::destroy
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:128
 * @route '/keuangan/anggaran/{anggaran}'
 */
destroy.url = (args: { anggaran: number | { id: number } } | [anggaran: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { anggaran: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { anggaran: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    anggaran: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        anggaran: typeof args.anggaran === 'object'
                ? args.anggaran.id
                : args.anggaran,
                }

    return destroy.definition.url
            .replace('{anggaran}', parsedArgs.anggaran.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\AnggaranController::destroy
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:128
 * @route '/keuangan/anggaran/{anggaran}'
 */
destroy.delete = (args: { anggaran: number | { id: number } } | [anggaran: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Keuangan\AnggaranController::destroy
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:128
 * @route '/keuangan/anggaran/{anggaran}'
 */
    const destroyForm = (args: { anggaran: number | { id: number } } | [anggaran: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\AnggaranController::destroy
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:128
 * @route '/keuangan/anggaran/{anggaran}'
 */
        destroyForm.delete = (args: { anggaran: number | { id: number } } | [anggaran: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Keuangan\AnggaranController::approve
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:100
 * @route '/keuangan/anggaran/{anggaran}/approve'
 */
export const approve = (args: { anggaran: number | { id: number } } | [anggaran: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

approve.definition = {
    methods: ["post"],
    url: '/keuangan/anggaran/{anggaran}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Keuangan\AnggaranController::approve
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:100
 * @route '/keuangan/anggaran/{anggaran}/approve'
 */
approve.url = (args: { anggaran: number | { id: number } } | [anggaran: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { anggaran: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { anggaran: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    anggaran: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        anggaran: typeof args.anggaran === 'object'
                ? args.anggaran.id
                : args.anggaran,
                }

    return approve.definition.url
            .replace('{anggaran}', parsedArgs.anggaran.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\AnggaranController::approve
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:100
 * @route '/keuangan/anggaran/{anggaran}/approve'
 */
approve.post = (args: { anggaran: number | { id: number } } | [anggaran: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Keuangan\AnggaranController::approve
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:100
 * @route '/keuangan/anggaran/{anggaran}/approve'
 */
    const approveForm = (args: { anggaran: number | { id: number } } | [anggaran: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approve.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\AnggaranController::approve
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:100
 * @route '/keuangan/anggaran/{anggaran}/approve'
 */
        approveForm.post = (args: { anggaran: number | { id: number } } | [anggaran: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approve.url(args, options),
            method: 'post',
        })
    
    approve.form = approveForm
/**
* @see \App\Http\Controllers\Keuangan\AnggaranController::reject
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:114
 * @route '/keuangan/anggaran/{anggaran}/reject'
 */
export const reject = (args: { anggaran: number | { id: number } } | [anggaran: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

reject.definition = {
    methods: ["post"],
    url: '/keuangan/anggaran/{anggaran}/reject',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Keuangan\AnggaranController::reject
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:114
 * @route '/keuangan/anggaran/{anggaran}/reject'
 */
reject.url = (args: { anggaran: number | { id: number } } | [anggaran: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { anggaran: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { anggaran: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    anggaran: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        anggaran: typeof args.anggaran === 'object'
                ? args.anggaran.id
                : args.anggaran,
                }

    return reject.definition.url
            .replace('{anggaran}', parsedArgs.anggaran.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\AnggaranController::reject
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:114
 * @route '/keuangan/anggaran/{anggaran}/reject'
 */
reject.post = (args: { anggaran: number | { id: number } } | [anggaran: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Keuangan\AnggaranController::reject
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:114
 * @route '/keuangan/anggaran/{anggaran}/reject'
 */
    const rejectForm = (args: { anggaran: number | { id: number } } | [anggaran: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reject.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\AnggaranController::reject
 * @see app/Http/Controllers/Keuangan/AnggaranController.php:114
 * @route '/keuangan/anggaran/{anggaran}/reject'
 */
        rejectForm.post = (args: { anggaran: number | { id: number } } | [anggaran: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reject.url(args, options),
            method: 'post',
        })
    
    reject.form = rejectForm
const anggaran = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
update: Object.assign(update, update),
ajukan: Object.assign(ajukan, ajukan),
destroy: Object.assign(destroy, destroy),
approve: Object.assign(approve, approve),
reject: Object.assign(reject, reject),
}

export default anggaran