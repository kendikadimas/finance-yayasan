import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Keuangan\NotificationController::read
 * @see app/Http/Controllers/Keuangan/NotificationController.php:11
 * @route '/keuangan/notifications/{notification}/read'
 */
export const read = (args: { notification: string | number } | [notification: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: read.url(args, options),
    method: 'post',
})

read.definition = {
    methods: ["post"],
    url: '/keuangan/notifications/{notification}/read',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Keuangan\NotificationController::read
 * @see app/Http/Controllers/Keuangan/NotificationController.php:11
 * @route '/keuangan/notifications/{notification}/read'
 */
read.url = (args: { notification: string | number } | [notification: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { notification: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    notification: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        notification: args.notification,
                }

    return read.definition.url
            .replace('{notification}', parsedArgs.notification.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\NotificationController::read
 * @see app/Http/Controllers/Keuangan/NotificationController.php:11
 * @route '/keuangan/notifications/{notification}/read'
 */
read.post = (args: { notification: string | number } | [notification: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: read.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Keuangan\NotificationController::read
 * @see app/Http/Controllers/Keuangan/NotificationController.php:11
 * @route '/keuangan/notifications/{notification}/read'
 */
    const readForm = (args: { notification: string | number } | [notification: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: read.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\NotificationController::read
 * @see app/Http/Controllers/Keuangan/NotificationController.php:11
 * @route '/keuangan/notifications/{notification}/read'
 */
        readForm.post = (args: { notification: string | number } | [notification: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: read.url(args, options),
            method: 'post',
        })
    
    read.form = readForm
/**
* @see \App\Http\Controllers\Keuangan\NotificationController::readAll
 * @see app/Http/Controllers/Keuangan/NotificationController.php:18
 * @route '/keuangan/notifications/read-all'
 */
export const readAll = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: readAll.url(options),
    method: 'post',
})

readAll.definition = {
    methods: ["post"],
    url: '/keuangan/notifications/read-all',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Keuangan\NotificationController::readAll
 * @see app/Http/Controllers/Keuangan/NotificationController.php:18
 * @route '/keuangan/notifications/read-all'
 */
readAll.url = (options?: RouteQueryOptions) => {
    return readAll.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\NotificationController::readAll
 * @see app/Http/Controllers/Keuangan/NotificationController.php:18
 * @route '/keuangan/notifications/read-all'
 */
readAll.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: readAll.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Keuangan\NotificationController::readAll
 * @see app/Http/Controllers/Keuangan/NotificationController.php:18
 * @route '/keuangan/notifications/read-all'
 */
    const readAllForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: readAll.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\NotificationController::readAll
 * @see app/Http/Controllers/Keuangan/NotificationController.php:18
 * @route '/keuangan/notifications/read-all'
 */
        readAllForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: readAll.url(options),
            method: 'post',
        })
    
    readAll.form = readAllForm
const notifications = {
    read: Object.assign(read, read),
readAll: Object.assign(readAll, readAll),
}

export default notifications