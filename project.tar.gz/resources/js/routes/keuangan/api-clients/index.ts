import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Keuangan\ApiClientController::index
 * @see app/Http/Controllers/Keuangan/ApiClientController.php:19
 * @route '/keuangan/api-clients'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/keuangan/api-clients',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Keuangan\ApiClientController::index
 * @see app/Http/Controllers/Keuangan/ApiClientController.php:19
 * @route '/keuangan/api-clients'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\ApiClientController::index
 * @see app/Http/Controllers/Keuangan/ApiClientController.php:19
 * @route '/keuangan/api-clients'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Keuangan\ApiClientController::index
 * @see app/Http/Controllers/Keuangan/ApiClientController.php:19
 * @route '/keuangan/api-clients'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Keuangan\ApiClientController::index
 * @see app/Http/Controllers/Keuangan/ApiClientController.php:19
 * @route '/keuangan/api-clients'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Keuangan\ApiClientController::index
 * @see app/Http/Controllers/Keuangan/ApiClientController.php:19
 * @route '/keuangan/api-clients'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Keuangan\ApiClientController::index
 * @see app/Http/Controllers/Keuangan/ApiClientController.php:19
 * @route '/keuangan/api-clients'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Keuangan\ApiClientController::store
 * @see app/Http/Controllers/Keuangan/ApiClientController.php:27
 * @route '/keuangan/api-clients'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/keuangan/api-clients',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Keuangan\ApiClientController::store
 * @see app/Http/Controllers/Keuangan/ApiClientController.php:27
 * @route '/keuangan/api-clients'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\ApiClientController::store
 * @see app/Http/Controllers/Keuangan/ApiClientController.php:27
 * @route '/keuangan/api-clients'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Keuangan\ApiClientController::store
 * @see app/Http/Controllers/Keuangan/ApiClientController.php:27
 * @route '/keuangan/api-clients'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\ApiClientController::store
 * @see app/Http/Controllers/Keuangan/ApiClientController.php:27
 * @route '/keuangan/api-clients'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Keuangan\ApiClientController::update
 * @see app/Http/Controllers/Keuangan/ApiClientController.php:49
 * @route '/keuangan/api-clients/{api_client}'
 */
export const update = (args: { api_client: number | { id: number } } | [api_client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/keuangan/api-clients/{api_client}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Keuangan\ApiClientController::update
 * @see app/Http/Controllers/Keuangan/ApiClientController.php:49
 * @route '/keuangan/api-clients/{api_client}'
 */
update.url = (args: { api_client: number | { id: number } } | [api_client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { api_client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { api_client: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    api_client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        api_client: typeof args.api_client === 'object'
                ? args.api_client.id
                : args.api_client,
                }

    return update.definition.url
            .replace('{api_client}', parsedArgs.api_client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\ApiClientController::update
 * @see app/Http/Controllers/Keuangan/ApiClientController.php:49
 * @route '/keuangan/api-clients/{api_client}'
 */
update.put = (args: { api_client: number | { id: number } } | [api_client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Keuangan\ApiClientController::update
 * @see app/Http/Controllers/Keuangan/ApiClientController.php:49
 * @route '/keuangan/api-clients/{api_client}'
 */
    const updateForm = (args: { api_client: number | { id: number } } | [api_client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\ApiClientController::update
 * @see app/Http/Controllers/Keuangan/ApiClientController.php:49
 * @route '/keuangan/api-clients/{api_client}'
 */
        updateForm.put = (args: { api_client: number | { id: number } } | [api_client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Keuangan\ApiClientController::regenerate
 * @see app/Http/Controllers/Keuangan/ApiClientController.php:61
 * @route '/keuangan/api-clients/{api_client}/regenerate'
 */
export const regenerate = (args: { api_client: number | { id: number } } | [api_client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: regenerate.url(args, options),
    method: 'post',
})

regenerate.definition = {
    methods: ["post"],
    url: '/keuangan/api-clients/{api_client}/regenerate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Keuangan\ApiClientController::regenerate
 * @see app/Http/Controllers/Keuangan/ApiClientController.php:61
 * @route '/keuangan/api-clients/{api_client}/regenerate'
 */
regenerate.url = (args: { api_client: number | { id: number } } | [api_client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { api_client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { api_client: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    api_client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        api_client: typeof args.api_client === 'object'
                ? args.api_client.id
                : args.api_client,
                }

    return regenerate.definition.url
            .replace('{api_client}', parsedArgs.api_client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\ApiClientController::regenerate
 * @see app/Http/Controllers/Keuangan/ApiClientController.php:61
 * @route '/keuangan/api-clients/{api_client}/regenerate'
 */
regenerate.post = (args: { api_client: number | { id: number } } | [api_client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: regenerate.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Keuangan\ApiClientController::regenerate
 * @see app/Http/Controllers/Keuangan/ApiClientController.php:61
 * @route '/keuangan/api-clients/{api_client}/regenerate'
 */
    const regenerateForm = (args: { api_client: number | { id: number } } | [api_client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: regenerate.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\ApiClientController::regenerate
 * @see app/Http/Controllers/Keuangan/ApiClientController.php:61
 * @route '/keuangan/api-clients/{api_client}/regenerate'
 */
        regenerateForm.post = (args: { api_client: number | { id: number } } | [api_client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: regenerate.url(args, options),
            method: 'post',
        })
    
    regenerate.form = regenerateForm
/**
* @see \App\Http\Controllers\Keuangan\ApiClientController::toggle
 * @see app/Http/Controllers/Keuangan/ApiClientController.php:83
 * @route '/keuangan/api-clients/{api_client}/toggle'
 */
export const toggle = (args: { api_client: number | { id: number } } | [api_client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggle.url(args, options),
    method: 'post',
})

toggle.definition = {
    methods: ["post"],
    url: '/keuangan/api-clients/{api_client}/toggle',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Keuangan\ApiClientController::toggle
 * @see app/Http/Controllers/Keuangan/ApiClientController.php:83
 * @route '/keuangan/api-clients/{api_client}/toggle'
 */
toggle.url = (args: { api_client: number | { id: number } } | [api_client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { api_client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { api_client: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    api_client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        api_client: typeof args.api_client === 'object'
                ? args.api_client.id
                : args.api_client,
                }

    return toggle.definition.url
            .replace('{api_client}', parsedArgs.api_client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\ApiClientController::toggle
 * @see app/Http/Controllers/Keuangan/ApiClientController.php:83
 * @route '/keuangan/api-clients/{api_client}/toggle'
 */
toggle.post = (args: { api_client: number | { id: number } } | [api_client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggle.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Keuangan\ApiClientController::toggle
 * @see app/Http/Controllers/Keuangan/ApiClientController.php:83
 * @route '/keuangan/api-clients/{api_client}/toggle'
 */
    const toggleForm = (args: { api_client: number | { id: number } } | [api_client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggle.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\ApiClientController::toggle
 * @see app/Http/Controllers/Keuangan/ApiClientController.php:83
 * @route '/keuangan/api-clients/{api_client}/toggle'
 */
        toggleForm.post = (args: { api_client: number | { id: number } } | [api_client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggle.url(args, options),
            method: 'post',
        })
    
    toggle.form = toggleForm
/**
* @see \App\Http\Controllers\Keuangan\ApiClientController::destroy
 * @see app/Http/Controllers/Keuangan/ApiClientController.php:91
 * @route '/keuangan/api-clients/{api_client}'
 */
export const destroy = (args: { api_client: number | { id: number } } | [api_client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/keuangan/api-clients/{api_client}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Keuangan\ApiClientController::destroy
 * @see app/Http/Controllers/Keuangan/ApiClientController.php:91
 * @route '/keuangan/api-clients/{api_client}'
 */
destroy.url = (args: { api_client: number | { id: number } } | [api_client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { api_client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { api_client: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    api_client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        api_client: typeof args.api_client === 'object'
                ? args.api_client.id
                : args.api_client,
                }

    return destroy.definition.url
            .replace('{api_client}', parsedArgs.api_client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\ApiClientController::destroy
 * @see app/Http/Controllers/Keuangan/ApiClientController.php:91
 * @route '/keuangan/api-clients/{api_client}'
 */
destroy.delete = (args: { api_client: number | { id: number } } | [api_client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Keuangan\ApiClientController::destroy
 * @see app/Http/Controllers/Keuangan/ApiClientController.php:91
 * @route '/keuangan/api-clients/{api_client}'
 */
    const destroyForm = (args: { api_client: number | { id: number } } | [api_client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\ApiClientController::destroy
 * @see app/Http/Controllers/Keuangan/ApiClientController.php:91
 * @route '/keuangan/api-clients/{api_client}'
 */
        destroyForm.delete = (args: { api_client: number | { id: number } } | [api_client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const apiClients = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
update: Object.assign(update, update),
regenerate: Object.assign(regenerate, regenerate),
toggle: Object.assign(toggle, toggle),
destroy: Object.assign(destroy, destroy),
}

export default apiClients