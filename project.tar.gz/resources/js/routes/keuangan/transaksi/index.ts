import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Keuangan\TransaksiController::index
 * @see app/Http/Controllers/Keuangan/TransaksiController.php:23
 * @route '/keuangan/transaksi'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/keuangan/transaksi',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Keuangan\TransaksiController::index
 * @see app/Http/Controllers/Keuangan/TransaksiController.php:23
 * @route '/keuangan/transaksi'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\TransaksiController::index
 * @see app/Http/Controllers/Keuangan/TransaksiController.php:23
 * @route '/keuangan/transaksi'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Keuangan\TransaksiController::index
 * @see app/Http/Controllers/Keuangan/TransaksiController.php:23
 * @route '/keuangan/transaksi'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Keuangan\TransaksiController::index
 * @see app/Http/Controllers/Keuangan/TransaksiController.php:23
 * @route '/keuangan/transaksi'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Keuangan\TransaksiController::index
 * @see app/Http/Controllers/Keuangan/TransaksiController.php:23
 * @route '/keuangan/transaksi'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Keuangan\TransaksiController::index
 * @see app/Http/Controllers/Keuangan/TransaksiController.php:23
 * @route '/keuangan/transaksi'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Keuangan\TransaksiController::store
 * @see app/Http/Controllers/Keuangan/TransaksiController.php:52
 * @route '/keuangan/transaksi'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/keuangan/transaksi',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Keuangan\TransaksiController::store
 * @see app/Http/Controllers/Keuangan/TransaksiController.php:52
 * @route '/keuangan/transaksi'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\TransaksiController::store
 * @see app/Http/Controllers/Keuangan/TransaksiController.php:52
 * @route '/keuangan/transaksi'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Keuangan\TransaksiController::store
 * @see app/Http/Controllers/Keuangan/TransaksiController.php:52
 * @route '/keuangan/transaksi'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\TransaksiController::store
 * @see app/Http/Controllers/Keuangan/TransaksiController.php:52
 * @route '/keuangan/transaksi'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Keuangan\TransaksiController::destroy
 * @see app/Http/Controllers/Keuangan/TransaksiController.php:75
 * @route '/keuangan/transaksi/{transaksi}'
 */
export const destroy = (args: { transaksi: number | { id: number } } | [transaksi: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/keuangan/transaksi/{transaksi}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Keuangan\TransaksiController::destroy
 * @see app/Http/Controllers/Keuangan/TransaksiController.php:75
 * @route '/keuangan/transaksi/{transaksi}'
 */
destroy.url = (args: { transaksi: number | { id: number } } | [transaksi: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { transaksi: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { transaksi: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    transaksi: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        transaksi: typeof args.transaksi === 'object'
                ? args.transaksi.id
                : args.transaksi,
                }

    return destroy.definition.url
            .replace('{transaksi}', parsedArgs.transaksi.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\TransaksiController::destroy
 * @see app/Http/Controllers/Keuangan/TransaksiController.php:75
 * @route '/keuangan/transaksi/{transaksi}'
 */
destroy.delete = (args: { transaksi: number | { id: number } } | [transaksi: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Keuangan\TransaksiController::destroy
 * @see app/Http/Controllers/Keuangan/TransaksiController.php:75
 * @route '/keuangan/transaksi/{transaksi}'
 */
    const destroyForm = (args: { transaksi: number | { id: number } } | [transaksi: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\TransaksiController::destroy
 * @see app/Http/Controllers/Keuangan/TransaksiController.php:75
 * @route '/keuangan/transaksi/{transaksi}'
 */
        destroyForm.delete = (args: { transaksi: number | { id: number } } | [transaksi: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const transaksi = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
destroy: Object.assign(destroy, destroy),
}

export default transaksi