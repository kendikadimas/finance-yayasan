import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Keuangan\KasBankAccountController::index
 * @see app/Http/Controllers/Keuangan/KasBankAccountController.php:19
 * @route '/keuangan/kas-bank'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/keuangan/kas-bank',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Keuangan\KasBankAccountController::index
 * @see app/Http/Controllers/Keuangan/KasBankAccountController.php:19
 * @route '/keuangan/kas-bank'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\KasBankAccountController::index
 * @see app/Http/Controllers/Keuangan/KasBankAccountController.php:19
 * @route '/keuangan/kas-bank'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Keuangan\KasBankAccountController::index
 * @see app/Http/Controllers/Keuangan/KasBankAccountController.php:19
 * @route '/keuangan/kas-bank'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Keuangan\KasBankAccountController::index
 * @see app/Http/Controllers/Keuangan/KasBankAccountController.php:19
 * @route '/keuangan/kas-bank'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Keuangan\KasBankAccountController::index
 * @see app/Http/Controllers/Keuangan/KasBankAccountController.php:19
 * @route '/keuangan/kas-bank'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Keuangan\KasBankAccountController::index
 * @see app/Http/Controllers/Keuangan/KasBankAccountController.php:19
 * @route '/keuangan/kas-bank'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Keuangan\KasBankAccountController::store
 * @see app/Http/Controllers/Keuangan/KasBankAccountController.php:34
 * @route '/keuangan/kas-bank'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/keuangan/kas-bank',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Keuangan\KasBankAccountController::store
 * @see app/Http/Controllers/Keuangan/KasBankAccountController.php:34
 * @route '/keuangan/kas-bank'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\KasBankAccountController::store
 * @see app/Http/Controllers/Keuangan/KasBankAccountController.php:34
 * @route '/keuangan/kas-bank'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Keuangan\KasBankAccountController::store
 * @see app/Http/Controllers/Keuangan/KasBankAccountController.php:34
 * @route '/keuangan/kas-bank'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\KasBankAccountController::store
 * @see app/Http/Controllers/Keuangan/KasBankAccountController.php:34
 * @route '/keuangan/kas-bank'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Keuangan\KasBankAccountController::update
 * @see app/Http/Controllers/Keuangan/KasBankAccountController.php:52
 * @route '/keuangan/kas-bank/{kas_bank_account}'
 */
export const update = (args: { kas_bank_account: number | { id: number } } | [kas_bank_account: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/keuangan/kas-bank/{kas_bank_account}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Keuangan\KasBankAccountController::update
 * @see app/Http/Controllers/Keuangan/KasBankAccountController.php:52
 * @route '/keuangan/kas-bank/{kas_bank_account}'
 */
update.url = (args: { kas_bank_account: number | { id: number } } | [kas_bank_account: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { kas_bank_account: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { kas_bank_account: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    kas_bank_account: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        kas_bank_account: typeof args.kas_bank_account === 'object'
                ? args.kas_bank_account.id
                : args.kas_bank_account,
                }

    return update.definition.url
            .replace('{kas_bank_account}', parsedArgs.kas_bank_account.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\KasBankAccountController::update
 * @see app/Http/Controllers/Keuangan/KasBankAccountController.php:52
 * @route '/keuangan/kas-bank/{kas_bank_account}'
 */
update.put = (args: { kas_bank_account: number | { id: number } } | [kas_bank_account: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Keuangan\KasBankAccountController::update
 * @see app/Http/Controllers/Keuangan/KasBankAccountController.php:52
 * @route '/keuangan/kas-bank/{kas_bank_account}'
 */
    const updateForm = (args: { kas_bank_account: number | { id: number } } | [kas_bank_account: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\KasBankAccountController::update
 * @see app/Http/Controllers/Keuangan/KasBankAccountController.php:52
 * @route '/keuangan/kas-bank/{kas_bank_account}'
 */
        updateForm.put = (args: { kas_bank_account: number | { id: number } } | [kas_bank_account: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Keuangan\KasBankAccountController::destroy
 * @see app/Http/Controllers/Keuangan/KasBankAccountController.php:68
 * @route '/keuangan/kas-bank/{kas_bank_account}'
 */
export const destroy = (args: { kas_bank_account: number | { id: number } } | [kas_bank_account: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/keuangan/kas-bank/{kas_bank_account}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Keuangan\KasBankAccountController::destroy
 * @see app/Http/Controllers/Keuangan/KasBankAccountController.php:68
 * @route '/keuangan/kas-bank/{kas_bank_account}'
 */
destroy.url = (args: { kas_bank_account: number | { id: number } } | [kas_bank_account: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { kas_bank_account: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { kas_bank_account: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    kas_bank_account: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        kas_bank_account: typeof args.kas_bank_account === 'object'
                ? args.kas_bank_account.id
                : args.kas_bank_account,
                }

    return destroy.definition.url
            .replace('{kas_bank_account}', parsedArgs.kas_bank_account.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\KasBankAccountController::destroy
 * @see app/Http/Controllers/Keuangan/KasBankAccountController.php:68
 * @route '/keuangan/kas-bank/{kas_bank_account}'
 */
destroy.delete = (args: { kas_bank_account: number | { id: number } } | [kas_bank_account: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Keuangan\KasBankAccountController::destroy
 * @see app/Http/Controllers/Keuangan/KasBankAccountController.php:68
 * @route '/keuangan/kas-bank/{kas_bank_account}'
 */
    const destroyForm = (args: { kas_bank_account: number | { id: number } } | [kas_bank_account: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\KasBankAccountController::destroy
 * @see app/Http/Controllers/Keuangan/KasBankAccountController.php:68
 * @route '/keuangan/kas-bank/{kas_bank_account}'
 */
        destroyForm.delete = (args: { kas_bank_account: number | { id: number } } | [kas_bank_account: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const kasBank = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default kasBank