import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Keuangan\UnitController::store
 * @see app/Http/Controllers/Keuangan/UnitController.php:24
 * @route '/keuangan/units'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/keuangan/units',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Keuangan\UnitController::store
 * @see app/Http/Controllers/Keuangan/UnitController.php:24
 * @route '/keuangan/units'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\UnitController::store
 * @see app/Http/Controllers/Keuangan/UnitController.php:24
 * @route '/keuangan/units'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Keuangan\UnitController::store
 * @see app/Http/Controllers/Keuangan/UnitController.php:24
 * @route '/keuangan/units'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\UnitController::store
 * @see app/Http/Controllers/Keuangan/UnitController.php:24
 * @route '/keuangan/units'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Keuangan\UnitController::update
 * @see app/Http/Controllers/Keuangan/UnitController.php:39
 * @route '/keuangan/units/{unit}'
 */
export const update = (args: { unit: number | { id: number } } | [unit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/keuangan/units/{unit}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Keuangan\UnitController::update
 * @see app/Http/Controllers/Keuangan/UnitController.php:39
 * @route '/keuangan/units/{unit}'
 */
update.url = (args: { unit: number | { id: number } } | [unit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unit: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { unit: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    unit: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        unit: typeof args.unit === 'object'
                ? args.unit.id
                : args.unit,
                }

    return update.definition.url
            .replace('{unit}', parsedArgs.unit.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\UnitController::update
 * @see app/Http/Controllers/Keuangan/UnitController.php:39
 * @route '/keuangan/units/{unit}'
 */
update.put = (args: { unit: number | { id: number } } | [unit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Keuangan\UnitController::update
 * @see app/Http/Controllers/Keuangan/UnitController.php:39
 * @route '/keuangan/units/{unit}'
 */
    const updateForm = (args: { unit: number | { id: number } } | [unit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\UnitController::update
 * @see app/Http/Controllers/Keuangan/UnitController.php:39
 * @route '/keuangan/units/{unit}'
 */
        updateForm.put = (args: { unit: number | { id: number } } | [unit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Keuangan\UnitController::destroy
 * @see app/Http/Controllers/Keuangan/UnitController.php:54
 * @route '/keuangan/units/{unit}'
 */
export const destroy = (args: { unit: number | { id: number } } | [unit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/keuangan/units/{unit}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Keuangan\UnitController::destroy
 * @see app/Http/Controllers/Keuangan/UnitController.php:54
 * @route '/keuangan/units/{unit}'
 */
destroy.url = (args: { unit: number | { id: number } } | [unit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { unit: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { unit: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    unit: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        unit: typeof args.unit === 'object'
                ? args.unit.id
                : args.unit,
                }

    return destroy.definition.url
            .replace('{unit}', parsedArgs.unit.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\UnitController::destroy
 * @see app/Http/Controllers/Keuangan/UnitController.php:54
 * @route '/keuangan/units/{unit}'
 */
destroy.delete = (args: { unit: number | { id: number } } | [unit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Keuangan\UnitController::destroy
 * @see app/Http/Controllers/Keuangan/UnitController.php:54
 * @route '/keuangan/units/{unit}'
 */
    const destroyForm = (args: { unit: number | { id: number } } | [unit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Keuangan\UnitController::destroy
 * @see app/Http/Controllers/Keuangan/UnitController.php:54
 * @route '/keuangan/units/{unit}'
 */
        destroyForm.delete = (args: { unit: number | { id: number } } | [unit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Keuangan\UnitController::index
 * @see app/Http/Controllers/Keuangan/UnitController.php:17
 * @route '/keuangan/units'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/keuangan/units',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Keuangan\UnitController::index
 * @see app/Http/Controllers/Keuangan/UnitController.php:17
 * @route '/keuangan/units'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Keuangan\UnitController::index
 * @see app/Http/Controllers/Keuangan/UnitController.php:17
 * @route '/keuangan/units'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Keuangan\UnitController::index
 * @see app/Http/Controllers/Keuangan/UnitController.php:17
 * @route '/keuangan/units'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Keuangan\UnitController::index
 * @see app/Http/Controllers/Keuangan/UnitController.php:17
 * @route '/keuangan/units'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Keuangan\UnitController::index
 * @see app/Http/Controllers/Keuangan/UnitController.php:17
 * @route '/keuangan/units'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Keuangan\UnitController::index
 * @see app/Http/Controllers/Keuangan/UnitController.php:17
 * @route '/keuangan/units'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const units = {
    store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
index: Object.assign(index, index),
}

export default units