import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\V1\TagihanSiswaController::index
 * @see app/Http/Controllers/Api/V1/TagihanSiswaController.php:20
 * @route '/api/v1/tagihan-siswa'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/v1/tagihan-siswa',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\TagihanSiswaController::index
 * @see app/Http/Controllers/Api/V1/TagihanSiswaController.php:20
 * @route '/api/v1/tagihan-siswa'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\TagihanSiswaController::index
 * @see app/Http/Controllers/Api/V1/TagihanSiswaController.php:20
 * @route '/api/v1/tagihan-siswa'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\V1\TagihanSiswaController::index
 * @see app/Http/Controllers/Api/V1/TagihanSiswaController.php:20
 * @route '/api/v1/tagihan-siswa'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\V1\TagihanSiswaController::index
 * @see app/Http/Controllers/Api/V1/TagihanSiswaController.php:20
 * @route '/api/v1/tagihan-siswa'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\V1\TagihanSiswaController::index
 * @see app/Http/Controllers/Api/V1/TagihanSiswaController.php:20
 * @route '/api/v1/tagihan-siswa'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\V1\TagihanSiswaController::index
 * @see app/Http/Controllers/Api/V1/TagihanSiswaController.php:20
 * @route '/api/v1/tagihan-siswa'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const tagihanSiswa = {
    index: Object.assign(index, index),
}

export default tagihanSiswa