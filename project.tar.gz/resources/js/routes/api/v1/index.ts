import pembayaranSpp from './pembayaran-spp'
import tagihanSiswa from './tagihan-siswa'
import hutangVendor from './hutang-vendor'
import penggajian from './penggajian'
import laporan from './laporan'
const v1 = {
    pembayaranSpp: Object.assign(pembayaranSpp, pembayaranSpp),
tagihanSiswa: Object.assign(tagihanSiswa, tagihanSiswa),
hutangVendor: Object.assign(hutangVendor, hutangVendor),
penggajian: Object.assign(penggajian, penggajian),
laporan: Object.assign(laporan, laporan),
}

export default v1