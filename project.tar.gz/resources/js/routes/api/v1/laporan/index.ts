import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\V1\LaporanRingkasanController::ringkasan
 * @see app/Http/Controllers/Api/V1/LaporanRingkasanController.php:21
 * @route '/api/v1/laporan/ringkasan'
 */
export const ringkasan = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ringkasan.url(options),
    method: 'get',
})

ringkasan.definition = {
    methods: ["get","head"],
    url: '/api/v1/laporan/ringkasan',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\V1\LaporanRingkasanController::ringkasan
 * @see app/Http/Controllers/Api/V1/LaporanRingkasanController.php:21
 * @route '/api/v1/laporan/ringkasan'
 */
ringkasan.url = (options?: RouteQueryOptions) => {
    return ringkasan.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\V1\LaporanRingkasanController::ringkasan
 * @see app/Http/Controllers/Api/V1/LaporanRingkasanController.php:21
 * @route '/api/v1/laporan/ringkasan'
 */
ringkasan.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: ringkasan.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\V1\LaporanRingkasanController::ringkasan
 * @see app/Http/Controllers/Api/V1/LaporanRingkasanController.php:21
 * @route '/api/v1/laporan/ringkasan'
 */
ringkasan.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: ringkasan.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\V1\LaporanRingkasanController::ringkasan
 * @see app/Http/Controllers/Api/V1/LaporanRingkasanController.php:21
 * @route '/api/v1/laporan/ringkasan'
 */
    const ringkasanForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: ringkasan.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\V1\LaporanRingkasanController::ringkasan
 * @see app/Http/Controllers/Api/V1/LaporanRingkasanController.php:21
 * @route '/api/v1/laporan/ringkasan'
 */
        ringkasanForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ringkasan.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\V1\LaporanRingkasanController::ringkasan
 * @see app/Http/Controllers/Api/V1/LaporanRingkasanController.php:21
 * @route '/api/v1/laporan/ringkasan'
 */
        ringkasanForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: ringkasan.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    ringkasan.form = ringkasanForm
const laporan = {
    ringkasan: Object.assign(ringkasan, ringkasan),
}

export default laporan